import React from 'react';
import defaultPortraitImg from '../assets/images/portrait_sketch_1787835296137.jpg';

interface ProfilePicProps {
  className?: string;
}

export const ProfilePic: React.FC<ProfilePicProps> = ({ className = '' }) => {
  return (
    <div 
      className={`relative w-28 h-28 sm:w-36 sm:h-36 mx-auto rounded-full overflow-hidden shadow-xl border-4 border-[#F9CA31] bg-[#FAFAF7] ring-4 ring-[#F9CA31]/20 ${className}`}
    >
      <img
        src={defaultPortraitImg}
        alt="Rai Usman Profile Picture"
        className="w-full h-full object-cover object-center filter contrast-110"
      />
    </div>
  );
};
