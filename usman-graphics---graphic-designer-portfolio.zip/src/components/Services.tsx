import React from 'react';
import {
  PenTool,
  Layers,
  PlaySquare,
  Share2,
  Image,
  Sliders,
  Target,
  Sparkles,
  Check
} from 'lucide-react';
import { SERVICES } from '../data';

// Icon mapper helper
const getServiceIcon = (iconName: string) => {
  switch (iconName) {
    case 'PenTool':
      return <PenTool className="w-6 h-6 text-[#C5A47E]" />;
    case 'Layers':
      return <Layers className="w-6 h-6 text-[#C5A47E]" />;
    case 'PlaySquare':
      return <PlaySquare className="w-6 h-6 text-[#C5A47E]" />;
    case 'Share2':
      return <Share2 className="w-6 h-6 text-[#C5A47E]" />;
    case 'Image':
      return <Image className="w-6 h-6 text-[#C5A47E]" />;
    case 'Sliders':
      return <Sliders className="w-6 h-6 text-[#C5A47E]" />;
    case 'Target':
      return <Target className="w-6 h-6 text-[#C5A47E]" />;
    case 'Sparkles':
      return <Sparkles className="w-6 h-6 text-[#C5A47E]" />;
    default:
      return <PenTool className="w-6 h-6 text-[#C5A47E]" />;
  }
};

interface ServicesProps {
  onOpenContact: () => void;
}

export const Services: React.FC<ServicesProps> = ({ onOpenContact }) => {
  return (
    <section id="services" className="py-24 bg-white relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#F9CA31]/5 rounded-full blur-[140px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FAFAF7] border border-[#F9CA31]/40 text-[#050505] text-xs font-semibold mb-4 uppercase tracking-widest shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#D8A915]" />
            <span>Professional Graphic Design Services</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#050505] tracking-tight">
            Tailored Creative Solutions to <span className="gold-gradient-text">Elevate Your Brand</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#666666] font-light">
            From iconic logo marks to high-converting marketing assets, I deliver pristine quality designed for international impact.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="brand-card brand-card-hover p-6 rounded-2xl flex flex-col justify-between group"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-[#F9CA31]/20 border border-[#F9CA31]/30 flex items-center justify-center mb-6 group-hover:bg-[#F9CA31] group-hover:text-[#050505] transition-all duration-300">
                  {getServiceIcon(service.iconName)}
                </div>

                <h3 className="text-lg font-bold text-[#050505] mb-3 group-hover:text-[#D8A915] transition-colors">
                  {service.title}
                </h3>

                <p className="text-[#666666] text-xs leading-relaxed mb-6 font-light">
                  {service.description}
                </p>
              </div>

              <div>
                <ul className="space-y-2 pt-4 border-t border-black/10 mb-6">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-xs text-[#050505] font-light">
                      <Check className="w-3.5 h-3.5 text-[#D8A915] shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={onOpenContact}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#FAFAF7] hover:bg-[#F9CA31] hover:text-[#050505] text-[#050505] font-semibold text-xs uppercase tracking-wider transition-all duration-300 border border-black/10 flex items-center justify-center gap-2"
                >
                  <span>Request Service</span>
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
