import React from 'react';
import { Mail, Phone, Heart } from 'lucide-react';
import { PERSONAL_INFO } from '../data';
import { Logo } from './Logo';

interface FooterProps {
  onNavigate?: (pageId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleNav = (pageId: string) => {
    if (onNavigate) {
      onNavigate(pageId);
    }
  };

  return (
    <footer className="bg-[#050505] border-t border-[#F9CA31]/20 text-[#FAFAF7]/80 pt-16 pb-12 shadow-2xl relative z-10">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand Column */}
          <div className="space-y-4">
            <button
              onClick={() => handleNav('home')}
              className="flex items-center gap-3 group text-left cursor-pointer"
            >
              <Logo size="sm" />
              <span className="text-lg font-semibold text-white group-hover:text-[#D8A915] transition-colors flex items-center gap-1.5">
                {PERSONAL_INFO.brandName}
              </span>
            </button>
            <p className="text-xs leading-relaxed text-[#FAFAF7]/60 font-light">
              {PERSONAL_INFO.tagline}
            </p>
            <div className="text-[10px] text-[#D8A915] font-bold uppercase tracking-wider">
              Principal Designer: {PERSONAL_INFO.name}
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-widest mb-4">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs font-light">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-[#D8A915] transition-colors text-left">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-[#D8A915] transition-colors text-left">
                  About Me
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('services')} className="hover:text-[#D8A915] transition-colors text-left">
                  Services
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('portfolio')} className="hover:text-[#D8A915] transition-colors text-left">
                  Projects
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('process')} className="hover:text-[#D8A915] transition-colors text-left">
                  Design Process
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-[#D8A915] transition-colors text-left">
                  Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-widest mb-4">
              Core Services
            </h4>
            <ul className="space-y-2 text-xs font-light">
              <li><button onClick={() => handleNav('services')} className="hover:text-[#D8A915] transition-colors text-left">Logo Design</button></li>
              <li><button onClick={() => handleNav('services')} className="hover:text-[#D8A915] transition-colors text-left">Brand Identity</button></li>
              <li><button onClick={() => handleNav('services')} className="hover:text-[#D8A915] transition-colors text-left">YouTube Thumbnails</button></li>
              <li><button onClick={() => handleNav('services')} className="hover:text-[#D8A915] transition-colors text-left">Social Media Design</button></li>
              <li><button onClick={() => handleNav('services')} className="hover:text-[#D8A915] transition-colors text-left">Marketing & Banners</button></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-xs uppercase tracking-widest mb-4">
              Direct Contact
            </h4>
            <div className="space-y-3 text-xs font-light">
              <a href={`mailto:${PERSONAL_INFO.emails[0]}`} className="flex items-center gap-2.5 text-[#FAFAF7]/80 hover:text-[#D8A915] transition-colors break-all">
                <Mail className="w-4 h-4 text-[#D8A915] shrink-0" />
                <span>{PERSONAL_INFO.emails[0]}</span>
              </a>
              <a href={`tel:${PERSONAL_INFO.phones[0].replace(/-/g, '')}`} className="flex items-center gap-2.5 text-[#FAFAF7]/80 hover:text-[#D8A915] transition-colors">
                <Phone className="w-4 h-4 text-[#D8A915] shrink-0" />
                <span>{PERSONAL_INFO.phones[0]}</span>
              </a>
            </div>
            <div className="pt-2">
              <span className="inline-block px-3 py-1 rounded-full bg-[#F9CA31]/20 text-[#F9CA31] text-[10px] font-bold uppercase tracking-wider border border-[#F9CA31]/30">
                Global Clients Welcome
              </span>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#FAFAF7]/50 font-light">
          <div>
            &copy; {new Date().getFullYear()} {PERSONAL_INFO.brandName} ({PERSONAL_INFO.name}). All rights reserved.
          </div>
          <div className="flex items-center gap-1.5">
            <span>Crafted with</span>
            <Heart className="w-3.5 h-3.5 text-[#F9CA31] fill-[#F9CA31]" />
            <span>for International Clients</span>
          </div>
        </div>

      </div>
    </footer>
  );
};

