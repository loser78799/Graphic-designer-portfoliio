import React from 'react';
import {
  Palette,
  Eye,
  Award,
  HeartHandshake,
  Zap,
  TrendingUp,
  Sparkles
} from 'lucide-react';
import { WHY_CHOOSE_ME } from '../data';

const getWhyIcon = (iconName: string) => {
  switch (iconName) {
    case 'Palette':
      return <Palette className="w-6 h-6 text-[#C5A47E]" />;
    case 'Eye':
      return <Eye className="w-6 h-6 text-[#C5A47E]" />;
    case 'Award':
      return <Award className="w-6 h-6 text-[#C5A47E]" />;
    case 'HeartHandshake':
      return <HeartHandshake className="w-6 h-6 text-[#C5A47E]" />;
    case 'Zap':
      return <Zap className="w-6 h-6 text-[#C5A47E]" />;
    case 'TrendingUp':
      return <TrendingUp className="w-6 h-6 text-[#C5A47E]" />;
    default:
      return <Sparkles className="w-6 h-6 text-[#C5A47E]" />;
  }
};

export const WhyChooseMe: React.FC = () => {
  return (
    <section className="py-24 bg-[#FAFAF7] relative">
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-[#F9CA31]/6 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-10 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-[#F9CA31]/40 text-[#050505] text-xs font-semibold mb-4 uppercase tracking-widest shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#D8A915]" />
            <span>Why Partner With Usman Graphics</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#050505] tracking-tight">
            Built on Creativity, Quality & <span className="gold-gradient-text">Absolute Trust</span>
          </h2>
          <p className="mt-4 text-base sm:text-lg text-[#666666] font-light">
            Why international clients and top-tier creators consistently choose Usman Graphics for their visual branding needs.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {WHY_CHOOSE_ME.map((item, idx) => (
            <div
              key={idx}
              className="brand-card brand-card-hover p-8 rounded-2xl group"
            >
              <div className="w-12 h-12 rounded-xl bg-[#F9CA31]/20 border border-[#F9CA31]/30 flex items-center justify-center mb-6 group-hover:bg-[#F9CA31] group-hover:text-[#050505] transition-all duration-300">
                {getWhyIcon(item.icon)}
              </div>
              <h3 className="text-lg font-bold text-[#050505] mb-3 group-hover:text-[#D8A915] transition-colors">
                {item.title}
              </h3>
              <p className="text-[#666666] text-xs leading-relaxed font-light">
                {item.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
